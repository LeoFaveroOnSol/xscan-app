# XSCAN Alpha — Chrome Extension

Real-time alpha calls from XSCAN's database, integrated directly into axiom.trade.

## Features
- **Floating panel** on axiom.trade showing latest token calls in real-time
- **Chart bubbles** showing when channels called the token you're viewing
- **Live updates** via Supabase Realtime websocket
- **Badge counter** on extension icon for new calls
- **Draggable/resizable** dark-themed panel
- **Keyboard shortcut** — `Alt+X` to toggle panel
- Settings popup with toggles for panel, notifications, chart bubbles

## Install (Unpacked)

1. Open Chrome → `chrome://extensions/`
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `/root/xscan-extension/` folder
5. Navigate to [axiom.trade](https://axiom.trade) — the panel appears automatically

## Usage
- The floating panel shows the latest 50 calls with token image, symbol, market cap at call, ATH multiplier, and channel name
- Click any call to open it on axiom.trade
- When viewing a token chart (`axiom.trade/t/{contract}`), chart bubbles show when channels called that token
- Click the extension icon to see stats and toggle settings
- Press `Alt+X` to show/hide the panel

## Architecture
- `manifest.json` — Manifest V3 config
- `background.js` — Service worker: Supabase Realtime websocket + REST API proxy
- `content.js` — Content script: floating panel + chart bubbles on axiom.trade
- `content.css` — Dark theme styles
- `popup.html/js` — Extension popup with settings
- `config.js` — Supabase credentials

## Data
Connects to existing XSCAN Supabase database:
- `telegram_calls` — token call data with market cap, multipliers, timestamps
- `telegram_channels` — channel metadata (display names)
