function formatMcap(n) {
  if (!n) return '?';
  n = Number(n);
  if (n >= 1e9) return '$' + (n/1e9).toFixed(1) + 'B';
  if (n >= 1e6) return '$' + (n/1e6).toFixed(1) + 'M';
  if (n >= 1e3) return '$' + (n/1e3).toFixed(1) + 'K';
  return '$' + n.toFixed(0);
}

function timeAgo(ts) {
  if (!ts) return '';
  const s = (Date.now() - new Date(ts).getTime()) / 1000;
  if (s < 60) return Math.floor(s) + 's';
  if (s < 3600) return Math.floor(s/60) + 'm';
  if (s < 86400) return Math.floor(s/3600) + 'h';
  return Math.floor(s/86400) + 'd';
}

// Load settings
chrome.storage.sync.get({ showPanel: true, showNotifs: false, showBubbles: true }, (s) => {
  document.getElementById('showPanel').checked = s.showPanel;
  document.getElementById('showNotifs').checked = s.showNotifs;
  document.getElementById('showBubbles').checked = s.showBubbles;
});

// Save settings
['showPanel', 'showNotifs', 'showBubbles'].forEach(id => {
  document.getElementById(id).addEventListener('change', (e) => {
    chrome.storage.sync.set({ [id]: e.target.checked });
  });
});

// Load calls
chrome.runtime.sendMessage({ type: 'FETCH_CALLS', limit: 20 }, (res) => {
  if (!res || !res.data) return;
  const data = res.data;
  const today = new Date().toISOString().slice(0, 10);
  
  document.getElementById('totalCalls').textContent = data.length;
  document.getElementById('todayCalls').textContent = data.filter(c => c.entry_timestamp && c.entry_timestamp.startsWith(today)).length;
  
  const list = document.getElementById('callsList');
  list.innerHTML = data.slice(0, 15).map(c => `
    <div class="call-row" data-addr="${c.token_address || ''}">
      <img src="${c.token_image_url || ''}" onerror="this.style.visibility='hidden'">
      <div class="info">
        <span class="sym">${c.token_symbol || '?'}</span> ${c.token_name || ''}
        <div class="mcap">${formatMcap(c.entry_market_cap)}</div>
      </div>
      <div class="time">${timeAgo(c.entry_timestamp)}</div>
    </div>
  `).join('');
  
  list.querySelectorAll('.call-row').forEach(el => {
    el.onclick = () => {
      const a = el.dataset.addr;
      if (a) chrome.tabs.create({ url: `https://axiom.trade/t/${a}` });
    };
  });
});

chrome.runtime.sendMessage({ type: 'CLEAR_BADGE' });
