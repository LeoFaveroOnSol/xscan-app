importScripts('config.js');

const API_URL = XSCAN_CONFIG.SUPABASE_URL + '/rest/v1';
const REALTIME_URL = XSCAN_CONFIG.SUPABASE_URL.replace('https://', 'wss://') + '/realtime/v1/websocket?apikey=' + XSCAN_CONFIG.SUPABASE_ANON_KEY + '&vsn=1.0.0';
const HEADERS = {
  'apikey': XSCAN_CONFIG.SUPABASE_ANON_KEY,
  'Authorization': 'Bearer ' + XSCAN_CONFIG.SUPABASE_ANON_KEY,
  'Content-Type': 'application/json'
};

let newCallCount = 0;
let realtimeWs = null;
let heartbeatRef = 0;
let heartbeatInterval = null;

// Badge
function updateBadge(count) {
  newCallCount = count;
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#9945FF' });
}

// Realtime subscription
function connectRealtime() {
  if (realtimeWs) { try { realtimeWs.close(); } catch(e){} }
  
  realtimeWs = new WebSocket(REALTIME_URL);
  
  realtimeWs.onopen = () => {
    // Join channel
    realtimeWs.send(JSON.stringify({
      topic: 'realtime:public:telegram_calls',
      event: 'phx_join',
      payload: { config: { broadcast: { self: false }, presence: { key: '' }, postgres_changes: [{ event: 'INSERT', schema: 'public', table: 'telegram_calls' }] } },
      ref: String(++heartbeatRef)
    }));
    
    // Heartbeat
    heartbeatInterval = setInterval(() => {
      if (realtimeWs.readyState === WebSocket.OPEN) {
        realtimeWs.send(JSON.stringify({ topic: 'phoenix', event: 'heartbeat', payload: {}, ref: String(++heartbeatRef) }));
      }
    }, 30000);
  };
  
  realtimeWs.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.event === 'postgres_changes' && msg.payload?.data?.record) {
      const call = msg.payload.data.record;
      updateBadge(newCallCount + 1);
      // Broadcast to content scripts
      chrome.tabs.query({ url: 'https://axiom.trade/*' }, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, { type: 'NEW_CALL', call }).catch(() => {});
        });
      });
    }
  };
  
  realtimeWs.onclose = () => {
    clearInterval(heartbeatInterval);
    setTimeout(connectRealtime, 5000);
  };
  
  realtimeWs.onerror = () => { realtimeWs.close(); };
}

// Message handling
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'FETCH_CALLS') {
    const params = new URLSearchParams({
      select: '*,telegram_channels(display_name,channel_username)',
      order: 'entry_timestamp.desc',
      limit: msg.limit || '50'
    });
    if (msg.token_address) {
      params.set('token_address', 'eq.' + msg.token_address);
    }
    fetch(`${API_URL}/telegram_calls?${params}`, { headers: HEADERS })
      .then(r => r.json())
      .then(data => sendResponse({ data }))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }
  
  if (msg.type === 'FETCH_CHANNELS') {
    fetch(`${API_URL}/telegram_channels?select=*`, { headers: HEADERS })
      .then(r => r.json())
      .then(data => sendResponse({ data }))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }
  
  if (msg.type === 'CLEAR_BADGE') {
    updateBadge(0);
    sendResponse({ ok: true });
    return false;
  }
  
  if (msg.type === 'GET_BADGE_COUNT') {
    sendResponse({ count: newCallCount });
    return false;
  }
});

// Toggle panel via keyboard shortcut
chrome.commands.onCommand.addListener((command) => {
  if (command === 'toggle-panel') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'TOGGLE_PANEL' }).catch(() => {});
    });
  }
});

// Start
chrome.runtime.onInstalled.addListener(() => { updateBadge(0); });
connectRealtime();
