const XSCAN_CONFIG = {
  SUPABASE_URL: 'https://mmdqkxaqgabsrhcccepf.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1tZHFreGFxZ2Fic3JoY2NjZXBmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc1NDAzODYsImV4cCI6MjA4MzExNjM4Nn0.JbsoymZdAQrbtz-Zu7GEK8ZVXcNNdWXWjTfKZ0IaDeE'
};

if (typeof module !== 'undefined') module.exports = XSCAN_CONFIG;
