(() => {
  'use strict';

  let panelVisible = true;
  let calls = [];
  let channelsMap = {};
  let isDragging = false;
  let dragOffset = { x: 0, y: 0 };
  const imageCache = new Map();

  // Helpers
  function formatMcap(n) {
    if (!n) return '?';
    n = Number(n);
    if (n >= 1e9) return '$' + (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return '$' + (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return '$' + (n / 1e3).toFixed(1) + 'K';
    return '$' + n.toFixed(0);
  }

  function timeAgo(ts) {
    if (!ts) return '';
    const diff = (Date.now() - new Date(ts).getTime()) / 1000;
    if (diff < 60) return Math.floor(diff) + 's';
    if (diff < 3600) return Math.floor(diff / 60) + 'm';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h';
    return Math.floor(diff / 86400) + 'd';
  }

  function getChannelName(call) {
    if (call.telegram_channels) return call.telegram_channels.display_name || call.telegram_channels.channel_username;
    return channelsMap[call.channel_id] || 'Unknown';
  }

  // Fetch token image from DexScreener
  async function getTokenImage(address, chain) {
    if (imageCache.has(address)) return imageCache.get(address);
    try {
      const ch = chain === 'bsc' ? 'bsc' : chain === 'solana' ? 'solana' : chain;
      const res = await fetch(`https://api.dexscreener.com/tokens/v1/${ch}/${address}`);
      const data = await res.json();
      const pairs = Array.isArray(data) ? data : (data?.pairs || []);
      if (pairs.length > 0) {
        const img = pairs[0].info?.imageUrl || null;
        imageCache.set(address, img);
        return img;
      }
    } catch (e) {}
    imageCache.set(address, null);
    return null;
  }

  async function loadImages() {
    const items = document.querySelectorAll('.xscan-call-item[data-address]');
    for (const item of items) {
      const addr = item.dataset.address;
      const chain = item.dataset.chain || 'solana';
      const img = item.querySelector('.xscan-call-img');
      if (!img || (img.src && img.src !== location.href)) continue;
      const url = await getTokenImage(addr, chain);
      if (url) {
        img.src = url;
        img.style.display = 'block';
        const placeholder = item.querySelector('.xscan-call-placeholder');
        if (placeholder) placeholder.style.display = 'none';
      }
    }
  }

  // Extract contract from current Axiom URL
  function getCurrentContract() {
    const m = window.location.pathname.match(/\/(?:t|meme)\/([A-Za-z0-9]+)/);
    return m ? m[1] : null;
  }

  // XSCAN Logo
  const XSCAN_LOGO = `<svg width="22" height="22" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="45" stroke="#00cc6a" stroke-width="6" fill="none"/>
    <path d="M30 35L45 50L30 65" stroke="#00cc6a" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M55 35H70M55 50H65M55 65H70" stroke="#00cc6a" stroke-width="5" stroke-linecap="round"/>
  </svg>`;

  // ==================== PANEL ====================
  function createPanel() {
    if (document.getElementById('xscan-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'xscan-panel';
    panel.innerHTML = `
      <div id="xscan-panel-header">
        <div class="xscan-logo">${XSCAN_LOGO}<span>XSCAN</span></div>
        <div class="xscan-controls">
          <button id="xscan-refresh" title="Refresh">↻</button>
          <button id="xscan-close" title="Close">×</button>
        </div>
      </div>
      <div id="xscan-filter-bar">
        <button class="xscan-chain-btn active" data-chain="all">All</button>
        <button class="xscan-chain-btn" data-chain="solana">SOL</button>
        <button class="xscan-chain-btn" data-chain="bsc">BSC</button>
      </div>
      <div id="xscan-calls-list"><div class="xscan-loading">Loading...</div></div>
    `;
    document.body.appendChild(panel);

    // Toggle button
    const toggle = document.createElement('button');
    toggle.id = 'xscan-toggle-btn';
    toggle.innerHTML = XSCAN_LOGO;
    toggle.title = 'Toggle XSCAN (Alt+X)';
    toggle.onclick = () => togglePanel();
    document.body.appendChild(toggle);

    // Chain filter
    panel.querySelectorAll('.xscan-chain-btn').forEach(btn => {
      btn.onclick = () => {
        panel.querySelectorAll('.xscan-chain-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderCalls();
      };
    });

    // Drag
    const header = document.getElementById('xscan-panel-header');
    header.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      isDragging = true;
      const rect = panel.getBoundingClientRect();
      dragOffset.x = e.clientX - rect.left;
      dragOffset.y = e.clientY - rect.top;
      panel.style.transition = 'none';
    });
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      panel.style.left = (e.clientX - dragOffset.x) + 'px';
      panel.style.top = (e.clientY - dragOffset.y) + 'px';
      panel.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => { isDragging = false; panel.style.transition = ''; });

    document.getElementById('xscan-close').onclick = () => togglePanel();
    document.getElementById('xscan-refresh').onclick = () => { loadCalls(); placeChartBubbles(); };
  }

  function togglePanel() {
    const panel = document.getElementById('xscan-panel');
    if (!panel) return;
    panelVisible = !panelVisible;
    panel.classList.toggle('hidden', !panelVisible);
  }

  function getActiveChainFilter() {
    const active = document.querySelector('.xscan-chain-btn.active');
    return active ? active.dataset.chain : 'all';
  }

  function renderCalls() {
    const list = document.getElementById('xscan-calls-list');
    if (!list) return;

    const chainFilter = getActiveChainFilter();
    const filtered = chainFilter === 'all' ? calls : calls.filter(c => c.chain === chainFilter);

    if (!filtered.length) {
      list.innerHTML = '<div class="xscan-loading">No calls yet</div>';
      return;
    }

    list.innerHTML = filtered.slice(0, 50).map(call => {
      const ch = getChannelName(call);
      const ath = call.ath_multiplier ? parseFloat(call.ath_multiplier) : null;
      const curr = call.current_multiplier ? parseFloat(call.current_multiplier) : ath;
      let multiClass = 'neutral', multiText = 'NEW';
      
      if (ath && ath >= 2) {
        multiClass = 'green';
        multiText = ath.toFixed(1) + 'x';
      } else if (curr && curr !== 1) {
        const pct = Math.round((curr - 1) * 100);
        multiClass = pct >= 0 ? 'green' : 'red';
        multiText = (pct >= 0 ? '+' : '') + pct + '%';
      } else if (ath === 1 || curr === 1) {
        multiText = '0%';
      }

      const imgSrc = call.token_image_url || imageCache.get(call.token_address) || '';
      const imgDisplay = imgSrc ? '' : 'style="display:none"';
      const placeholder = imgSrc ? 'style="display:none"' : '';
      const initial = (call.token_symbol || '?')[0].toUpperCase();

      return `
        <div class="xscan-call-item" data-address="${call.token_address || ''}" data-chain="${call.chain || ''}" title="${call.token_name || call.token_symbol}">
          <div class="xscan-img-wrap">
            <img class="xscan-call-img" src="${imgSrc}" ${imgDisplay} onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" alt="">
            <div class="xscan-call-placeholder" ${placeholder}>${initial}</div>
          </div>
          <div class="xscan-call-info">
            <div class="xscan-call-name">${call.token_symbol || '?'} <span class="xscan-call-fullname">${call.token_name || ''}</span></div>
            <div class="xscan-call-meta">
              <span class="xscan-call-mcap">${formatMcap(call.entry_market_cap)}</span>
              <span class="xscan-call-channel">${ch}</span>
            </div>
          </div>
          <div class="xscan-call-right">
            <div class="xscan-call-multi ${multiClass}">${multiText}</div>
            <div class="xscan-call-time">${timeAgo(call.entry_timestamp)}</div>
          </div>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.xscan-call-item').forEach(el => {
      el.addEventListener('click', () => {
        const addr = el.dataset.address;
        if (addr) window.open(`https://axiom.trade/t/${addr}`, '_blank');
      });
    });

    loadImages();
  }

  // ==================== CHART BUBBLES ====================
  
  // Parse time labels from the chart's X-axis to map timestamps to pixel positions
  function getTimeAxisInfo() {
    // Axiom uses TradingView lightweight-charts or similar
    // Look for the time axis labels in the DOM
    const chartContainer = document.querySelector('[class*="chart"]') || 
                           document.querySelector('.tv-lightweight-charts') ||
                           document.querySelector('canvas')?.parentElement?.parentElement;
    if (!chartContainer) return null;

    // Find all canvases (TradingView renders on canvas)
    const canvases = chartContainer.querySelectorAll('canvas');
    if (!canvases.length) return null;

    // The main chart canvas is usually the largest one
    let mainCanvas = null;
    let maxArea = 0;
    canvases.forEach(c => {
      const area = c.width * c.height;
      if (area > maxArea) { maxArea = area; mainCanvas = c; }
    });
    if (!mainCanvas) return null;

    const rect = mainCanvas.getBoundingClientRect();
    
    // Try to find time labels in the DOM (some chart libs render them as text nodes)
    const timeLabels = [];
    const textElements = chartContainer.querySelectorAll('span, div');
    const timeRegex = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/;
    const dateTimeRegex = /^(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+'?(\d{2,4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/i;
    
    textElements.forEach(el => {
      const text = el.textContent.trim();
      const elRect = el.getBoundingClientRect();
      
      // Only consider elements near the bottom of the chart (x-axis area)
      if (elRect.top < rect.bottom - 40 || elRect.top > rect.bottom + 40) return;
      
      const m = text.match(timeRegex);
      if (m) {
        timeLabels.push({
          x: elRect.left + elRect.width / 2 - rect.left,
          hours: parseInt(m[1]),
          minutes: parseInt(m[2]),
          text
        });
      }
    });

    return { rect, mainCanvas, timeLabels, chartContainer };
  }

  // Map a timestamp to an X pixel position on the chart
  function timestampToChartX(timestamp, axisInfo) {
    if (!axisInfo || axisInfo.timeLabels.length < 2) return null;
    
    const callDate = new Date(timestamp);
    const callMinutes = callDate.getHours() * 60 + callDate.getMinutes();
    
    // Sort labels by x position
    const labels = [...axisInfo.timeLabels].sort((a, b) => a.x - b.x);
    
    // Find the two labels that bracket our time
    for (let i = 0; i < labels.length - 1; i++) {
      const l1 = labels[i];
      const l2 = labels[i + 1];
      const m1 = l1.hours * 60 + l1.minutes;
      const m2 = l2.hours * 60 + l2.minutes;
      
      // Handle day wrap (e.g. 23:00 -> 01:00)
      const adjustedM2 = m2 < m1 ? m2 + 1440 : m2;
      let adjustedCall = callMinutes;
      if (m2 < m1 && callMinutes < m1) adjustedCall += 1440;
      
      if (adjustedCall >= m1 && adjustedCall <= adjustedM2) {
        const ratio = (adjustedCall - m1) / (adjustedM2 - m1);
        return l1.x + ratio * (l2.x - l1.x);
      }
    }
    
    // If outside visible range, try extrapolation from closest pair
    const first = labels[0];
    const last = labels[labels.length - 1];
    const firstM = first.hours * 60 + first.minutes;
    const lastM = last.hours * 60 + last.minutes;
    
    // Pixels per minute
    const pxPerMin = (last.x - first.x) / ((lastM > firstM ? lastM - firstM : lastM + 1440 - firstM));
    const diffMin = callMinutes - firstM;
    const x = first.x + diffMin * pxPerMin;
    
    if (x >= 0 && x <= axisInfo.rect.width) return x;
    return null;
  }

  function placeChartBubbles() {
    // Remove old bubbles
    document.querySelectorAll('.xscan-chart-bubble').forEach(el => el.remove());
    
    const contract = getCurrentContract();
    if (!contract) return;

    chrome.runtime.sendMessage({ type: 'FETCH_CALLS', token_address: contract, limit: 20 }, (res) => {
      if (!res || !res.data || !res.data.length) return;

      const axisInfo = getTimeAxisInfo();
      if (!axisInfo || !axisInfo.rect) return;

      // We need a positioned parent to place bubbles
      const parent = axisInfo.mainCanvas.closest('div') || axisInfo.mainCanvas.parentElement;
      if (!parent) return;
      if (getComputedStyle(parent).position === 'static') parent.style.position = 'relative';

      res.data.forEach(call => {
        if (!call.entry_timestamp) return;
        
        const x = timestampToChartX(call.entry_timestamp, axisInfo);
        if (x === null) return;
        
        const ch = getChannelName(call);
        
        const bubble = document.createElement('div');
        bubble.className = 'xscan-chart-bubble';
        
        // Tooltip
        bubble.innerHTML = `
          <div class="xscan-bubble-tooltip">
            <span class="xscan-tt-channel">${ch}</span>
            <span class="xscan-tt-mcap">${formatMcap(call.entry_market_cap)}</span>
          </div>
        `;
        
        // Position: X from timestamp, Y at top portion of chart
        bubble.style.left = x + 'px';
        bubble.style.top = '30px';
        
        bubble.addEventListener('click', (e) => {
          e.stopPropagation();
          if (call.message_url) window.open(call.message_url, '_blank');
        });
        
        parent.appendChild(bubble);
      });
    });
  }

  // ==================== COMMS ====================
  
  function loadCalls() {
    chrome.runtime.sendMessage({ type: 'FETCH_CALLS', limit: 50 }, (res) => {
      if (res && res.data) {
        calls = res.data;
        renderCalls();
      }
    });
    chrome.runtime.sendMessage({ type: 'CLEAR_BADGE' });
  }

  function loadChannels() {
    chrome.runtime.sendMessage({ type: 'FETCH_CHANNELS' }, (res) => {
      if (res && res.data) {
        res.data.forEach(ch => { channelsMap[ch.id] = ch.display_name || ch.channel_username; });
      }
    });
  }

  // Listen for new calls from background
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'NEW_CALL') {
      calls.unshift(msg.call);
      renderCalls();
      const contract = getCurrentContract();
      if (contract && msg.call.token_address === contract) {
        setTimeout(placeChartBubbles, 1000);
      }
    }
    if (msg.type === 'TOGGLE_PANEL') {
      togglePanel();
    }
  });

  // Keyboard shortcut
  document.addEventListener('keydown', (e) => {
    if (e.altKey && e.key === 'x') togglePanel();
  });

  // Watch for URL changes (navigate to different token)
  let lastUrl = location.href;
  const urlObserver = new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(placeChartBubbles, 2000);
    }
  });
  urlObserver.observe(document.body, { childList: true, subtree: true });

  // Watch for chart redraws
  let chartObserverActive = false;
  function watchChart() {
    if (chartObserverActive) return;
    const chartEl = document.querySelector('[class*="chart"]') || document.querySelector('canvas')?.parentElement;
    if (!chartEl) return;
    chartObserverActive = true;
    const observer = new MutationObserver(() => {
      // Debounce: only re-place bubbles after chart stabilizes
      clearTimeout(watchChart._timer);
      watchChart._timer = setTimeout(placeChartBubbles, 500);
    });
    observer.observe(chartEl, { childList: true, subtree: true, attributes: true });
  }

  // ==================== INIT ====================
  createPanel();
  loadChannels();
  loadCalls();
  
  // Delay bubble placement to let chart render
  setTimeout(() => { placeChartBubbles(); watchChart(); }, 3000);

  // Periodic refresh
  setInterval(loadCalls, 60000);
  setInterval(() => { placeChartBubbles(); watchChart(); }, 30000);
})();
